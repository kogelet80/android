package com.example.exercise;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.exercise.SecondActivity.DATA_KEY;

public class MainActivity extends AppCompatActivity {



    private Button mButton;
    private EditText mEditText;


    private View.OnClickListener mOnEnterClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (isDataValid()) {
                String mString = mEditText.getText().toString();
                Toast toast = Toast.makeText(getApplicationContext(), mString, Toast.LENGTH_LONG);
                toast.show();

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra(SecondActivity.DATA_KEY, mEditText.getText().toString());
                startActivity(intent);

                mString = mEditText.getText().toString();

                mEditText.setText("");
            } else {
                // todo
            }
        }
    };
    private boolean isDataValid() {
        return !TextUtils.isEmpty(mEditText.getText());
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButton = findViewById(R.id.button);
        mEditText = findViewById(R.id.edtext);

        mButton.setOnClickListener(mOnEnterClickListener);


    }
}
