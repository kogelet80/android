package com.example.exercise;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    public static String DATA_KEY = "DATA_KEY";

    private TextView mTextView;
    private Button mSecondButton;

    private View.OnClickListener mOnEnterClickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Uri address = Uri.parse("https://www.google.com/search?q="+mTextView.getText().toString());
            Intent intent2 = new Intent(Intent.ACTION_VIEW, address);
            startActivity(intent2);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        mTextView = findViewById(R.id.textview);
        mSecondButton = findViewById(R.id.secondbutton);

        Bundle bundle = getIntent().getExtras();
        mTextView.setText(bundle.getString(DATA_KEY));

        mSecondButton.setOnClickListener(mOnEnterClickListener2);



    }
}
